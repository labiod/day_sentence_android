package com.bitage.daysentence.dao

import com.bitage.daysentence.dto.SentenceDTO
import io.reactivex.Observable
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito

class DaySentenceDAOTest {
    @Before
    fun setupTest() {
    }

    @Test
    fun testDaySentence_checkThatReturnOnlyOneItem() {

    }
}